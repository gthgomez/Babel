# Native qualification and cost/quality evaluation

## Two different claims

1. **Harness comparison:** Same task, starting revision, model endpoint, reasoning/output budget, maximum expenditure, tools/permissions and cache regime where technically possible. Record remaining interface differences. Isolate harness effects.
2. **Product comparison:** Each product's supported recommended configuration. Report model, versions, settings, dollars, time and intervention. Do not attribute the result solely to harness architecture.

## Before any model spending

Re-fetch main and open PRs. Build a clean checkout and run native deterministic regressions. Preserve the audited commit as a comparison baseline rather than rewriting history. Obtain an explicit live-evaluation budget; a roadmap is not permission for unbounded API spending.

Use the existing scripts from babel-cli/package.json as integration points: scripts/run_agent_benchmark.ts, scripts/run_coding_canary.ts, scripts/run_live_parity_corpus.ts, scripts/audit_token_usage.ts, scripts/audit_provider_pricing.ts, scripts/audit_cli_performance.ts and scripts/tui_benchmark.ts. Inspect each implementation before assigning a new responsibility; the audit verified the manifest entrypoints, not every script body.

## Proposed 24-task pilot

| Family | Tasks | Required distinction |
|---|---:|---|
| Read-only explanation and investigation | 4 | Correct answer, useful evidence, zero unintended writes |
| Single-file bug fixes | 4 | Behavioral oracle, no lexical fake-fix acceptance |
| Multi-file changes | 4 | Complete interface/test changes, no hidden regression |
| Compaction/resume/cancellation | 4 | Original intent, revision and authority survive |
| Provider faults and output limits | 4 | Typed cause, bounded retry, original cost owner |
| CLI/protocol/TUI workflow parity | 4 | Same operation/outcome; usable cancellation and recovery |

This size is for instrumentation and finding failure classes, not for a statistically strong superiority claim. Expand the held-out set once the measurement path is qualified. Repeat stochastic tasks; predeclare the analysis and quality regression margin rather than deciding it after viewing results.

## Required row schema

- task_id, task_definition_hash, repo, base_sha, acceptance_oracle_hash
- harness_version, executable_hash, host_os, entrypoint
- provider, requested_model, observed_model, route, capability snapshot
- authority_profile, instruction_manifest_digest, tool_schema_digest
- parent_task, attempt_id, request_id, auxiliary purpose
- uncached_input_tokens, cache_read_tokens, cache_write_tokens, output_tokens, reasoning accounting convention
- provider_reported_cost, computed_estimate, pricing_quote_id, pricing_verified_at, cost_confidence
- TTFT, total duration, retry count, read count, edit attempts, verifier runs, child count
- compaction count, context generation, retrieved ranges, omitted evidence, cache-prefix change reason
- semantic_acceptance, terminal_reason, interventions, infrastructure_failure, unknown_effects
- final candidate revision, independent reviewer scope and receipt

Normalize counters per provider; do not assume cache writes or reasoning tokens should always be added on top of prompt/output totals.

## Metrics

```
cost_per_accepted_task = total_known_spend_for_all_attempts / accepted_tasks
```

Show this as a **known subtotal** if any charges are unknown. If accepted_tasks is zero, report undefined. Also publish success fraction, intervention rate, p50/p95 duration, cost per attempted task and unknown-cost fraction. Separate API dollars from subscription-product access constraints; do not invent per-request prices for an unmetered interface.

Use blinded review of diffs and acceptance results where feasible. Keep runtime authority invariant across optimization variants. Compare warm and cold caches separately. Never compare a warm candidate with a cold baseline without disclosure.

## Optimization ladder

1. Native correctness repairs, with no new optimization claim.
2. Baseline plain strong-agent loop and current Babel loop.
3. Stable instruction/tool prefix with valid policy epochs.
4. Bounded reference-backed tool outputs and complete-round tail retention.
5. Current summaries versus verbatim pruning versus advisory incremental extraction.
6. Read/progress nudge ablations, then bounded model-adaptive critic/delegation changes.
7. Only then selective extra sampling at high-value decisions.

Every variant must preserve stop/cancel, deny, root, evidence freshness and unknown-cost semantics. A cheaper variant that lowers acceptance is not a win under the user's objective.
