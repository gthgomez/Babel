# Prioritized roadmap: repair, qualify, simplify, differentiate

This is an execution overlay on issue #217 and the existing P01–P21 dependency graph, not a replacement architecture or a new numbering system. N01–N09 identify issue drafts in this packet only.

## Phase 0 — Reconcile the actual baseline

**Order:** first. **Owner:** integration/qualification owner.

Pin fresh main and candidates; update #217/#231's stale R1 status. Record which #211–#216 obligations have native evidence after #251. Fix N01 Windows coverage qualification without hiding skips. Preserve the older #206 candidate until its unique accepted changes are accounted for; do not delete or merge blindly.

**Exit:** exact-head mandatory checks pass with a documented Windows scenario inventory. Old issues are closed only against their own acceptance evidence. Main, candidate, source qualification and field qualification are stated separately.

## Phase 1 — Repair high-leverage runtime boundaries

**Order:** N02 billing and N03 compaction first; N04 read identity next; N05 budget semantics and N06 auxiliary lifecycle immediately after. One integration owner for shared ChatEngine/context interfaces. Separate billing and test work may proceed in isolated worktrees with clear file ownership.

| Draft | Primary source owner | Required proof |
|---|---|---|
| N02 cache/price settlement | services/costTracker.ts, modelPricingRegistry.ts, agent/chatEngineProviderAccounting.ts | Provider-shaped counters, cache-aware amounts, late/replayed charges and stable quote basis |
| N03 compaction pressure | agent/compactionCommit.ts, chatCompaction.ts | Reserve-band and forced reduction; complete protocol pairs; explicit irreducible over-budget result; resume |
| N04 read identity | agent/readThrashPolicy.ts, ChatEngine read-key caller, existing root/observation services | POSIX case/space identity, Windows root semantics, invalidation after edits and compaction |
| N05 request admission | runners/preparedProviderRequest.ts, providerMessages.ts | Explicit-null precedence, estimator confidence, reserve and supported request shape |
| N06 auxiliary lifecycle | agent/chatCompaction.ts, existing provider/accounting boundaries | Pre-aborted zero dispatch, midflight cancel, approved route, correct owner and known/unknown usage |

**Exit:** native tests reproduce the defects before the patch and pass afterward; chat-truth/runtime/acceptance checks pass on exact head; no authority, replay or unknown-cost regression. This is not yet a claim of better benchmark performance.

## Phase 2 — Qualify the real product path

**Work:** N07 native evaluation; #206/#267 integration and terminal qualification; N09 clean-room packaging. Product and terminal owners may proceed separately from core repairs, but their final results must qualify the integrated head.

**CLI acceptance:** clean install, version/source identity, one useful task, structured/headless parity, cancel/resume, clear environment/provider failure and safe uninstall.

**TUI acceptance:** real 160×45 reference capture plus smaller responsive modes; Windows/ConPTY and POSIX; resize, CJK/IME, paste, scrolling, selection, long output, abort and draft preservation. Navigation is executable, and unknown evidence/cost is visible rather than fabricated.

**Evaluation acceptance:** fresh native trajectories, behavioral oracles, full-cohort cost accounting and confidence labels. No canned trajectory presented as native success.

**Exit:** representative end-to-end scenarios are accepted on a packaged candidate, and a user can tell what it did, what was verified and why it stopped.

## Phase 3 — Optimize and simplify against measurements

**Work:** N08 stable-prefix/pruning experiments; operation-aware progress and read-fuse ablations; bounded model-specific tool/critic profiles. Existing #253/#257/#258 provide steering, attempt and provider-window invariants.

Keep authority/evidence checks fixed while simplifying advisory orchestration. Default to a strong single worker plus deterministic acceptance and bounded specialized review; use children when independence or parallelizable work justifies them. Separate telemetry from model-visible prompt text.

**Exit:** no predeclared quality regression, lower full-cohort price-weighted cost or materially better success at equal cost, and no worsening of critical recovery/terminal scenarios. Otherwise leave the optimization off or remove it.

## Phase 4 — Strengthen differentiated acceptance

**Work:** existing #259–#265, governed by #266. Staged source-linked obligations, effect settlement, channel authority, independent custody, deployment assurance and non-amplifying delegation. Do not treat commodity orchestration as differentiation.

Implement this as extensions of existing task/authority/evidence/runtime contracts. Prove one heterogeneous producer path—for example, evaluating a candidate produced externally—before building a generalized ecosystem layer.

**Exit:** a machine-checkable decision can explain whether an exact candidate earned its claimed lifecycle state and what missing/invalid evidence prevents advancement.

## Explicit deferrals

Do not launch a Rust rewrite, mandatory daemon, new vector memory system, new ledger, third TUI renderer, always-on five-way sampling, unrestricted generic supervisor, or broad automatic memory-to-policy promotion to chase competitor feature lists. These may become experiments only after a measured need and a bounded design.

## Integration discipline

Use one serialized merge train. Assign the context/ChatEngine lifecycle to one owner. Reviewers get the exact base/head and full diff, not stale receipts. Test/benchmark/UI specialists can operate independently, but a claim about the combined product requires combined-head evidence. After repeated failures in one seam, fix the contract and class of tests rather than adding arbitrary exceptions.
