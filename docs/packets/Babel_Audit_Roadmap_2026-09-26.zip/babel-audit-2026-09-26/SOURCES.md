# Evidence inventory

Babel source is pinned; issue/PR/release pages are mutable. Line ranges describe what was inspected, not source coverage certification.

### B01 — main snapshot
https://github.com/gthgomez/Babel/commit/bd155087e41a53599470b86859fe7f45c1036a47

GitHub metadata; exact pinned baseline

### B02 — R1 integration
https://github.com/gthgomez/Babel/pull/251

Merged 2026-09-26 18:37:56Z; historical body still describes blocked candidate

### B03 — Windows CI
https://github.com/gthgomez/Babel/actions/runs/16978244012/job/108487011810

Retrieved log: 905 tests, 892 passed, 0 failed, 13 skipped; allowed skips 11

### B04 — North Star candidate
https://github.com/gthgomez/Babel/pull/267

Head 6758618af3a95d68d33147bd046d2f9dd76b93de; opt-in; real terminal qualification outstanding

### B05 — Reliability hub
https://github.com/gthgomez/Babel/issues/217

Header is stale after R1 merge; retain existing dependency and acceptance contracts

### B06 — Pricing settlement
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/services/costTracker.ts

Inspected 1-250 and 330-660; settleUsage drops cache counters at pricing call

### B07 — Pricing registry
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/services/modelPricingRegistry.ts

Inspected 1-320; pinned price basis is not a current vendor quote

### B08 — Compaction caller
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/agent/compactionCommit.ts

Inspected 940-1160 and other sections; reserve/force trigger mismatches manager target

### B09 — Compaction strategies
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/agent/chatCompaction.ts

Inspected strategy eligibility, summarization provenance, provider calls, manager

### B10 — Read cache policy
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/agent/readThrashPolicy.ts

Full helper; case/space collisions; mutation-biased advisory text

### B11 — Request preparation
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/runners/preparedProviderRequest.ts

Full helper; exact serialized body versus approximate token accounting; null/alias precedence

### B12 — Wire mapping/accounting
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/runners/providerMessages.ts

Approximate bytes/4 estimator; provenance and protocol validation

### B13 — Instruction assembly
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/agent/chatStackCompile.ts

Includes/truncates/omits optional sections; mandatory safety/provider/verifier reserved

### B14 — Interactive execution
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/interactive/execution/chatCore.ts

Shared entrypoint, operation-aware intent guidance, preflight, outcomes; targeted sections

### B15 — Engine integration
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/agent/chatEngine.ts

Targeted source and call-site inspection; not every branch executed or read

### B16 — Owner accounting
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/agent/chatEngineOwnerAccounting.ts

Late retired-owner charges and durable receipt restoration exist

### B17 — Provider accounting
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/agent/chatEngineProviderAccounting.ts

Dispatch-scoped pending charge, unstarted clearing, late usage attribution

### B18 — Governed exact edits
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/src/agent/governedMutations.ts

Central policy write path; process.env bridge remains; pre-policy read needs caller-scope audit

### B19 — Package
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/package.json

Inspected manifest/scripts; name babel-cli; bins babel/babel-lite/bl; many existing eval scripts

### B20 — Launcher
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/babel-cli/bin/babel.js

Package-relative dist import and missing-build diagnostic

### B21 — Status
https://github.com/gthgomez/Babel/blob/bd155087e41a53599470b86859fe7f45c1036a47/docs/STATUS.md

Product qualification and clone/build documentation; not a fresh release certification

### B22 — Candidate layout
https://github.com/gthgomez/Babel/blob/6758618af3a95d68d33147bd046d2f9dd76b93de/babel-cli/src/ui/shell/shellLayout.ts

Responsive linear/narrow/medium/wide geometry exists

### B23 — Candidate renderer
https://github.com/gthgomez/Babel/blob/6758618af3a95d68d33147bd046d2f9dd76b93de/babel-cli/src/ui/shell/shellFrameRenderer.ts

Grapheme/terminal sanitization, changed-row writes, commit after successful frame

### C01 — Codex current release
https://github.com/openai/codex/releases/tag/rust-v0.157.1

Latest retrieved stable release; published 2026-09-26 01:02:31Z

### C02 — Codex prior release notes
https://github.com/openai/codex/releases/tag/rust-v0.157.0

Product workflow improvements; not evidence of head-to-head task superiority

### C03 — Codex compaction source
https://github.com/openai/codex/blob/rust-v0.157.1/codex-rs/core/src/compact.rs

Inspected 1-270; phases/triggers, context reinjection, metadata and failure handling

### C04 — OpenAI loop explanation
https://openai.com/index/unrolling-the-codex-agent-loop/

Primary explanation; historical conceptual context, not release-specific source

### M01 — MiMo release
https://github.com/XiaomiMiMo/MiMo-Code/releases/tag/v0.1.15

Latest retrieved release; 2026-09-22; sequencing, flood control, resume fixes

### M02 — MiMo launch report
https://mimo.xiaomi.com/blog/mimo-code-long-horizon

Vendor report dated 2026-06-10; Claude Code comparison, not verified Codex comparison

### M03 — MiMo compaction
https://github.com/XiaomiMiMo/MiMo-Code/blob/v0.1.15/packages/opencode/src/session/compaction.ts

Inspected 1-300; complete rounds, bounded tail, omitted-output markers

### M04 — MiMo prefix snapshots
https://github.com/XiaomiMiMo/MiMo-Code/blob/v0.1.15/packages/opencode/src/session/prefix-snapshot.ts

Persistent system/tool snapshots with profile, permissions, revision, watermark

### M05 — MiMo package
https://github.com/XiaomiMiMo/MiMo-Code/blob/v0.1.15/package.json

OpenCode-derived workspace; Bun and OpenTUI dependencies

### R01 — CliffCompaction abstract
https://arxiv.org/abs/2609.26779

September 22 preprint; experiment candidate, no Babel performance claim
