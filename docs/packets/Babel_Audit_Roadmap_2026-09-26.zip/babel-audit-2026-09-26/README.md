# Babel audit packet · September 26, 2026

Start with **REPORT.md**, then **ROADMAP.md**. Implementation details are in **IMPLEMENTATION_PLAN.md**; the execution boundary is in **AGENT_HANDOFF.md**.

- Nine ready-to-file issue drafts and 22 existing-issue update drafts: `issues/`.
- One proposed joint TUI PR reconciliation: `issues/updates/pr-206-and-267.md`.
- Seven executed isolated counterexamples: `probes/source-logic-probes.mjs`, `probes/results.json`, `probes/run.log`.
- Comparison/evaluation design: `EVALUATION_PROTOCOL.md`.
- Pinned source references and limitations: `SOURCES.md`, `snapshot.json`.

**No repository changes and no GitHub publication. No native Babel execution, live provider benchmark or real terminal qualification.** The source-logic probes reproduce current counterexamples; their passing status does not mean Babel is fixed.

Run the isolated probes locally with Node:

```sh
node probes/source-logic-probes.mjs
```

See `MANIFEST.sha256` for artifact integrity. Local N identifiers are not GitHub numbers. All benchmark improvements and UX targets are proposals unless explicitly labeled observed source or hosted evidence.
