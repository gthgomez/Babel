/**
 * Isolated source-logic counterexamples, NOT native Babel tests.
 * Audited source: gthgomez/Babel @ bd155087e41a53599470b86859fe7f45c1036a47.
 * Small expressions/functions are reproduced below; no repository is imported.
 * Passing means a current-behavior counterexample was reproduced, not a fix passed.
 * No network, provider requests, user files, or product code are touched.
 */
import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
const observations = [];
function probe(id, title, run) {
  const evidence = run();
  observations.push({ id, title, level: 'COMPONENT_PROBED_SOURCE_LOGIC_ONLY', reproduced: true, ...evidence });
  console.log(`REPRODUCED ${id}: ${title}`);
}

// compactionCommit.ts::runChatEngineCompaction, chatCompaction.ts::canApply
function compactionDecision({ tokens, maxTokens, reserve, force = false, tokenTriggered = false }) {
  return {
    callerRequestsCompaction: force || tokenTriggered || tokens > maxTokens - reserve,
    strategyEligible: tokens > maxTokens,
  };
}
probe('P01', 'reserve-band trigger can select no eligible compaction strategy', () => {
  const actual = compactionDecision({ tokens: 95_000, maxTokens: 100_000, reserve: 8_000 });
  assert.equal(actual.callerRequestsCompaction, true);
  assert.equal(actual.strategyEligible, false);
  return actual;
});
probe('P02', 'forced recovery below full limit still fails strategy eligibility', () => {
  const actual = compactionDecision({ tokens: 70_000, maxTokens: 100_000, reserve: 8_000, force: true });
  assert.equal(actual.callerRequestsCompaction, true);
  assert.equal(actual.strategyEligible, false);
  return actual;
});

// costTracker.ts::settleUsage drops cache fields from the pricing-function call.
// Rates are repository-pinned fixtures, not a claim about current vendor prices.
function fixtureEstimate({ promptTokens, completionTokens, promptCacheHitTokens, promptCacheMissTokens }) {
  const hitRate = 0.0028, missRate = 0.14, outputRate = 0.28;
  const input = promptCacheHitTokens != null || promptCacheMissTokens != null
    ? ((promptCacheHitTokens ?? 0) * hitRate + (promptCacheMissTokens ?? Math.max(promptTokens - (promptCacheHitTokens ?? 0), 0)) * missRate) / 1e6
    : promptTokens * missRate / 1e6;
  return input + completionTokens * outputRate / 1e6;
}
probe('P03', 'cache counters omitted by caller materially change pinned-rate estimate', () => {
  const passedByCurrentTracker = fixtureEstimate({ promptTokens: 1_000_000, completionTokens: 10_000 });
  const cacheAware = fixtureEstimate({ promptTokens: 1_000_000, completionTokens: 10_000, promptCacheHitTokens: 900_000, promptCacheMissTokens: 100_000 });
  assert.ok(Math.abs(passedByCurrentTracker - 0.1428) < 1e-12);
  assert.ok(Math.abs(cacheAware - 0.01932) < 1e-12);
  assert.ok(passedByCurrentTracker > cacheAware);
  return { currentEstimateUsd: passedByCurrentTracker, cacheAwareEstimateUsd: cacheAware, ratio: passedByCurrentTracker / cacheAware, priceBasis: 'repository-pinned fixture only' };
});

// preparedProviderRequest.ts::resolveContextLimit
probe('P04', 'explicit unknown context ceiling is overridden by deprecated alias', () => {
  const input = { contextLimitTokens: null, inputLimitTokens: 12345 };
  const currentExplicitLimit = input.contextLimitTokens ?? input.inputLimitTokens;
  assert.equal(currentExplicitLimit, 12345);
  assert.notEqual(currentExplicitLimit, null);
  return { input, currentExplicitLimit, contractExpected: null, liveDualFieldCallerProven: false };
});

// chatCompaction.ts::callOpenAiCompatibleApi signal wiring (no fetch performed).
probe('P05', 'adding only an abort listener misses a pre-aborted parent', () => {
  const parent = new AbortController();
  parent.abort();
  const child = new AbortController();
  const listener = () => child.abort();
  parent.signal.addEventListener('abort', listener, { once: true });
  assert.equal(parent.signal.aborted, true);
  assert.equal(child.signal.aborted, false);
  parent.signal.removeEventListener('abort', listener);
  return { parentAborted: parent.signal.aborted, childAborted: child.signal.aborted, providerRequestPerformed: false, nativeReachabilityProven: false };
});

// readThrashPolicy.ts::normalizeReadCacheKey, with TS types removed only.
function normalizeReadCacheKey(filePath, projectRoot) {
  let p = filePath.trim().replace(/\\/g, '/');
  if (!p) return p;
  if (p.startsWith('file://')) {
    p = p.slice('file://'.length);
    if (/^\/[A-Za-z]:\//.test(p)) p = p.slice(1);
  }
  if (/^[A-Za-z]:\//.test(p)) p = p[0].toLowerCase() + p.slice(1);
  if (projectRoot && !/^[A-Za-z]:\//.test(p) && !p.startsWith('/')) {
    const root = projectRoot.replace(/\\/g, '/').replace(/\/$/, '');
    const rootKey = /^[A-Za-z]:\//.test(root) ? root[0].toLowerCase() + root.slice(1) : root;
    p = `${rootKey}/${p}`.replace(/\/+/g, '/');
  }
  p = p.replace(/\/\.\//g, '/');
  if (/^[A-Za-z]:\//.test(p) || p.includes('/Workspace/') || p.includes('/workspace/')) p = p.toLowerCase();
  return p;
}
probe('P06', 'case-sensitive workspace files collide in read-cache key', () => {
  const a = normalizeReadCacheKey('/workspace/Repo/A.ts');
  const b = normalizeReadCacheKey('/workspace/Repo/a.ts');
  assert.equal(a, b);
  return { paths: ['/workspace/Repo/A.ts', '/workspace/Repo/a.ts'], keys: [a, b], nativeSuppressionProven: false };
});
probe('P07', 'significant leading space in relative filename is lost', () => {
  const a = normalizeReadCacheKey(' A.ts', '/tmp/repo');
  const b = normalizeReadCacheKey('A.ts', '/tmp/repo');
  assert.equal(a, b);
  return { paths: [' A.ts', 'A.ts'], keys: [a, b], nativeSuppressionProven: false };
});

const result = {
  auditSha: 'bd155087e41a53599470b86859fe7f45c1036a47',
  node: process.version,
  generatedAt: new Date().toISOString(),
  scope: 'Seven isolated source-logic counterexamples. No native Babel suite, build, live provider or terminal qualification.',
  total: observations.length,
  reproduced: observations.filter(x => x.reproduced).length,
  observations,
};
writeFileSync(fileURLToPath(new URL('./results.json', import.meta.url)), JSON.stringify(result, null, 2) + '\n');
console.log(`\n${result.reproduced}/${result.total} isolated counterexamples reproduced. Native Babel verification: NOT RUN.`);
