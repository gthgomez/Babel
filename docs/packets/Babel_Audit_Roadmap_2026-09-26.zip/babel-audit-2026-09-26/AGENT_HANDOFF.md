# Execution handoff

Investigate fresh `gthgomez/Babel` main, then apply this packet as a reconciliation overlay—not a restart of the architecture campaign. Read `snapshot.json`, `REPORT.md`, `ROADMAP.md`, `IMPLEMENTATION_PLAN.md`, `issues/INDEX.md` and the current #217 first. The audited SHA is pinned; source may have changed.

First mission: reconcile current CI and close N01, then implement N02–N04 in bounded reviewed slices with native failing tests before fixes. Preserve R1's advisory-summary, owner-charge and authority work. N05/N06 follow. Do not implement every future idea just because it appears in the roadmap.

Issue publication: this session created **no GitHub issues/comments**. Use an authorized issue-writing action to search again, post only nonduplicate drafts and return real issue numbers. Existing issue updates are proposed comments/status updates, not new tickets. Keep #258 quota semantics separate from N02 pricing, and #231 documentation separate from N09 installer implementation.

Use isolated worktrees and one serialized integration owner for shared engine/context files. Specialists can inspect tests, billing, terminal and release artifacts in parallel with explicit file ownership. Do not create parallel ledgers, memory systems, renderer roots or control planes.

The seven `probes/` checks are isolated source-logic counterexamples, not production tests and not qualification. Reproduce each relevant condition through actual Babel tests. No live model run, native checkout test, benchmark or terminal capture was performed by the audit session. Obtain a live-evaluation budget before API spending.

Stop a slice when its native acceptance is met and exact-head review/CI is complete; report evidence and residual uncertainty. Do not disable gates, fabricate captures, assert task success from test-run infrastructure success, or overwrite user files to make a benchmark pass. Follow repository protection and review requirements for any eventual merge.
