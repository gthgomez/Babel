# Babel Daily-Driver Boundary Repairs — Implementation Plan

> **For agentic workers:** Use the installed Superpowers execution and test-driven workflows. Execute bounded tasks in order; use isolated worktrees for independent file owners. This is a proposed implementation plan, not a claim that runtime code was changed.

**Goal:** Repair confirmed high-impact boundaries, qualify the packaged coding experience, then optimize full-task cost without weakening semantic acceptance.

**Architecture:** Extend current preparation, compaction, billing, identity, evidence and UI owners. Keep model summaries advisory and authority/revision/cost settlement deterministic. No new ledger, mandatory daemon or replacement renderer.

**Tech stack:** Existing TypeScript/Node project and its pinned lockfile. Existing native test runner and CI wrappers; no runtime dependency addition required by the first defect repairs.

**Spec:** `REPORT.md`, `ROADMAP.md`, `EVALUATION_PROTOCOL.md`, and issue drafts N01–N09.

## Global constraints

Audit source is `bd155087e41a53599470b86859fe7f45c1036a47`. Refresh main before editing and document differences. Do not weaken root, permission, cancellation, revision, tool-protocol, receipt or unknown-cost checks. Keep `BABEL_TUI_SHELL=1` opt-in until separate field qualification. Do not infer successful independent review from a provider call or a passing unit test. No automatic publish, merge or unbounded API spend.

## Review focus

A task cancelled before dispatch must not send an auxiliary request. A successor task must not inherit its predecessor's authority or late charges. A compacted context must not pretend discarded file content is still present. Provider counters and price confidence must survive cold resume. A successful tool process must not be mistaken for semantic task acceptance. These conditions are assigned below, not deferred to an unspecified later audit.

## Shared native verification commands

Run inside `babel-cli` after a clean, approved dependency install:

```sh
npm ci
npx --no-install tsc --noEmit
npm run build
npm run check:dist
npm run check:source-provenance
npm run test:chat-truth
npm run test:harness-runtime
```

The test scripts alone do not replace the strict CI skip wrapper. Fetch the exact workflow file used by the candidate job, run its same wrapper invocation and require hosted exact-head results. Do not guess the wrapper's CLI interface from this packet. Targeted commands below import existing local `tsx`; run no live provider requests without a budget.

## Task 0 — Baseline and Windows coverage

**Files:** `scripts/run-tests.mjs`; `babel-cli/package.json`; `src/testinfra/chatTruthSelection.test.ts`; `src/testinfra/requiredTapSummary.test.ts`; `src/agent/windowsProcessQualification.test.ts` (src paths relative to babel-cli).

**Consumes:** exact CI test-selection and skip policy. **Produces:** qualified skip inventory and the same strict test semantics, not a relaxed allowance.

- [ ] Record fresh main, both TUI candidate refs, and all required check identities.
- [ ] Reproduce N01 with the exact Windows workflow command; preserve all skip identities.
- [ ] Add a regression for accidental skip growth or selection drift, then implement the smallest platform-coverage correction.
- [ ] Run the native selection/summary tests, full strict Linux/Windows jobs and the shared command set.
- [ ] Update only current-state blocks in #217/#231 and attach exact-head evidence. Commit separately from runtime changes.

## Task 1 — Cache-aware settlement

**Modify:** `src/services/costTracker.ts`, `src/services/modelPricingRegistry.ts`, `src/agent/chatEngineProviderAccounting.ts`, and runner metadata types only where route/quote information cannot already be carried.
**Tests:** `src/services/costTracker.test.ts`; extend the existing pricing tests after locating their current canonical file.

**Consumes:** `CostTracker.settleUsage(modelId,inputTokens,outputTokens,cacheHitTokens,cacheMissTokens,attribution,usageKnown)` and `estimateProviderUsageCost(UsageCostInput)`.
**Produces:** the same idempotent charge result with cache-aware amount and durable provider/price-basis confidence; any signature migration must update all callers in one reviewed slice.

- [ ] Add a failing native test for 1M prompt / 900k hit / 100k miss / 10k output using the repository fixture rates: expect $0.01932, not $0.1428.
- [ ] Forward cache fields; preserve missing versus zero. Add route identity through the established metadata/attribution contract rather than another registry.
- [ ] Add all-hit, no-cache, missing/partial usage, invalid counters, duplicate/refined charge, late retired owner, child-parent and cold-resume cases.
- [ ] Persist estimate/report confidence and pinned quote identity; ensure historical replay does not silently reprice.
- [ ] Run `node --import tsx --import ./src/testinfra/register-no-ambient-inference.mjs --test src/services/costTracker.test.ts`, shared tests and strict hosted checks. Commit as a billing boundary repair.

## Task 2 — One compaction pressure contract

**Modify:** `src/agent/compactionCommit.ts`, `src/agent/chatCompaction.ts`, and the direct host adapter in `src/agent/chatEngine.ts` if needed.
**Tests:** `src/agent/compactionCommit.test.ts`, `src/agent/chatCompaction.test.ts`, existing context-oracle/runtime tests.

**Consumes:** `runChatEngineCompaction(host)`, `CompactionManager.compactWithResult(messages, options)`, strategy `canApply`.
**Produces:** a coherent trigger/target contract and an explicit applied/no-op/failure outcome that downstream request admission can interpret.

- [ ] Add failing tests for 95k/100k/8k reserve and forced 70k/100k contexts with enough compactable history.
- [ ] Make eligibility use the requested reduction target and trigger, not a contradictory full-limit test. Keep output reserve explicit; never fix by fabricating the token count.
- [ ] Add no-compactable-history, required-content-too-large, exact-boundary, summarizer failure and changed=false cases with bounded outcomes.
- [ ] Prove advisory provenance, complete tool rounds, owner cancellation, durable checkpoint, resume and final-request re-admission remain correct.
- [ ] Run `node --import tsx --import ./src/testinfra/register-no-ambient-inference.mjs --test src/agent/compactionCommit.test.ts src/agent/chatCompaction.test.ts`, shared runtime/context checks and strict hosted CI. Commit separately from optimization.

## Task 3 — Read identity and delivery freshness

**Modify:** `src/agent/readThrashPolicy.ts`; engine read-key adapter; existing codingLoop read/observation bindings. Resolve the exported working-state owner rather than adding a new cache.
**Tests:** `src/agent/readThrashPolicy.test.ts` plus a native engine regression in the existing lifecycle/read context suite.

**Consumes:** `normalizeReadCacheKey(filePath, projectRoot)` and read-suppression decisions.
**Produces:** non-colliding identity on supported filesystems and a justified suppression decision scoped to revision/range/context generation.

- [ ] Create actual temporary files `A.ts`, `a.ts` where case-sensitive, and ` A.ts`/`A.ts`; assert distinct read identities. Test Windows semantics separately rather than skipping the obligation.
- [ ] Remove path-spelling-based filesystem assumptions. Reuse existing physical root identity and handle missing/symlink/permission cases explicitly.
- [ ] Run a read → compact → needed reread case and a read → external edit → reread case through the native loop.
- [ ] Replace count-only content-presence and mutation assertions with truthful observations; preserve operation-aware no-write behavior.
- [ ] Run `node --import tsx --import ./src/testinfra/register-no-ambient-inference.mjs --test src/agent/readThrashPolicy.test.ts`, associated native lifecycle tests and strict hosted CI.

## Task 4 — Request confidence and auxiliary cancellation

Split into two commits because a reviewer may accept null-precedence independently of auxiliary lifecycle consolidation.

**4A files:** `src/runners/preparedProviderRequest.ts`, `providerMessages.ts` and corresponding `.test.ts` files.
**4A contract:** explicit new field, including null, wins over deprecated alias; exact bytes/digest and estimated token confidence remain separate.

- [ ] Add a failing test for `{contextLimitTokens:null,inputLimitTokens:12345}`; expect unknown.
- [ ] Repair property precedence and test undefined/null/invalid/conflicting values.
- [ ] Add request-shape, output-reserve and estimator-confidence cases. Calibrate supported models from real usage only in the separately budgeted evaluation lane.
- [ ] Run `node --import tsx --import ./src/testinfra/register-no-ambient-inference.mjs --test src/runners/preparedProviderRequest.test.ts src/runners/providerMessages.test.ts` and shared checks.

**4B files:** `src/agent/chatCompaction.ts`, its tests, existing prepared-request/provider-accounting adapters.
**4B contract:** pre-aborted signal means zero fetch; later cancellation and late usage preserve original task/route ownership.

- [ ] Stub transport and add a native pre-aborted test asserting zero calls. Add cancel-before-headers, cancel-during-body and timeout causes.
- [ ] Check `signal.aborted` before dispatch and use existing abort/deadline helpers where compatible.
- [ ] Test approved summarizer route/local-only restrictions, callback identity and late/unknown usage. Preserve current endpoint-model-key coherence checks.
- [ ] Run compaction/provider/native lifecycle tests and exact-head hosted CI.

## Task 5 — Qualification, not another benchmark platform

**Files:** existing `scripts/run_agent_benchmark.ts`, `run_coding_canary.ts`, `run_live_parity_corpus.ts`, cost/usage audit scripts, current corpus/eval and ledger owners. These entrypoints were verified from the manifest; inspect their bodies before selecting the narrow implementation seam.

**Produces:** native run records obeying EVALUATION_PROTOCOL.md and separate deterministic versus live evidence.

- [ ] Add a failing reporting test proving failed attempts and auxiliary spend cannot disappear from cost per accepted task.
- [ ] Add unknown-cost and zero-accepted-task behavior, behavior-oracle integrity and infrastructure-failure classification.
- [ ] Extend the existing runners for the pilot and export stable per-task records.
- [ ] With an explicitly approved budget, run baseline and repaired candidate on the pilot; no premature superiority claim.

## Task 6 — TUI integration and clean package

**TUI files:** candidate `src/ui/shell/*`, `src/ui/historyCells/*`, input/prompt ownership and interactive execution bindings identified in PR #267. Preserve the candidate's working renderer rather than reimplementing it.

- [ ] Reconcile #206/#267 ancestry and unique behaviors onto the qualified current runtime.
- [ ] Add failing interaction/byte-stream regressions for actual observed terminal faults, not invented screenshots.
- [ ] Capture real Windows/POSIX runs including 160×45 and narrow fallbacks; record exact executable and dimensions.
- [ ] Require real controls, preserved drafts, usable scroll/copy, bounded output and truthful state before default enablement.

**Package files:** `package.json`, `bin/babel.js`, existing build/provenance scripts and canonical onboarding docs.

- [ ] Confirm approved package/bin naming; do not silently rename user commands.
- [ ] Build and `npm pack` locally; inspect the tarball for assets, dependencies and secret/private contamination.
- [ ] Install into clean Windows/POSIX hosts without source tree or devDependencies; prove help/version/diagnostic and a budgeted canary.
- [ ] Record artifact digest and results. Publishing remains a separate authorized action.

## Task 7 — Optional optimization and later acceptance work

Only after N02–N07 have useful native evidence, implement N08 variants behind flags. One variant per reviewable change; preserve authority while changing context presentation. Retain the winner only if full-task acceptance and cost justify it. Later #259–#265 work extends existing evidence/authority owners under #266; it does not justify a new generic orchestration framework.

## Final handoff format

Report exact base/head; changed files; pre-fix failure and post-fix native output; tests not run; Windows/POSIX evidence; cost basis; remaining acceptance gaps; and the next dependency-valid slice. Never replace a failed semantic oracle with a lexical check, raise thresholds without rationale, close issues from source presence alone, or merge without the protected path.
