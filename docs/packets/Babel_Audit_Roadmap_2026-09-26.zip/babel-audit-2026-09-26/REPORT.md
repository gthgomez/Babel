# Babel agent-harness audit
## September 26, 2026 · pinned-source review

**Baseline:** `bd155087e41a53599470b86859fe7f45c1036a47` in `gthgomez/Babel`.
**Comparison baselines:** Codex `rust-v0.157.1`; MiMo Code `v0.1.15`.
**Evidence:** GitHub source, PRs, issue backlog and CI logs; official competitor source and announcements; seven isolated source-logic counterexamples. Native Babel execution, live model evaluation and real-terminal testing were not performed.

## Decision

Make Babel a reliable daily coding tool with an inspectable acceptance layer before increasing orchestration breadth. The strongest direction is a simple, model-adaptable coding loop plus deterministic authority/evidence boundaries—not maximum numbers of agents, prompts, policies or receipts. That is a prioritization judgment, not a measured comparative benchmark.

The audited code has meaningful strengths: central governed edits, advisory rather than authoritative model summaries, explicit request identity, durable context/receipt machinery, late-charge ownership and separated terminal outcomes. These are real source-level improvements over older audit descriptions. They do not establish successful end-to-end task completion, lower total cost or a polished default TUI. [B06–B18]

The immediate weaknesses are concrete: Windows coverage qualification is red; cache fields are lost before price calculation; compaction can be requested while neither strategy is eligible; a read-cache helper conflates distinct POSIX paths; and request-budget confidence has stronger labels than its approximate tokenizer evidence warrants. [B03, B06–B12]

## 1. What changed since earlier planning

PR #251 merged September 26 at 18:37:56 UTC. Its historical description and the September 24 header of issue #217 still describe an unmerged integration. Update those summaries without deleting historical evidence. Do not reopen all old implementation work just because the issues remain open. Conversely, a merge alone does not satisfy every acceptance obligation. [B02, B05]

Current main's Windows job reports 905 tests: 892 pass, none fail assertions, and 13 skip. The strict wrapper allows 11 skips and exits nonzero. This is a coverage/qualification failure, not thirteen failing assertions. Keep the ratchet; explain or replace the extra skips using platform evidence rather than making CI cosmetically green. [B03]

North Star #267 is an opt-in candidate at `6758618af3a95d68d33147bd046d2f9dd76b93de`, alongside the older #206 lane. Its real-terminal qualification is not complete. Candidate source, snapshot tests, default product behavior and a real terminal recording are four different kinds of evidence. [B04, B22, B23]

## 2. Concrete findings

### F01 — Windows qualification is currently red

**Priority:** P0 release/integration blocker. **Evidence:** hosted CI log.

Owner: the existing strict test runner, chat-truth selection and Windows qualification fixtures. Preserve the suite allowance unless a reviewed, justified policy change is itself the intended deliverable. Identify every changed skip, assign its missing behavior, and establish which are inherently POSIX versus missing Windows coverage. Re-run Linux and Windows at the exact candidate head. [B03]

### F02 — Cache-aware prices are not reaching task settlement

**Priority:** P1. **Evidence:** source-confirmed plus isolated calculation P03.

`CostTracker.settleUsage()` accepts cache hit/miss counters, but calls `estimateProviderUsageCost()` with only model, provider inferred from the registry, prompt tokens and completion tokens. The price function supports cache fields; its caller drops them. [B06, B07]

Using the repository's pinned DeepSeek V4 Flash rates, 1,000,000 input tokens, 900,000 cache hits, 100,000 misses and 10,000 output tokens produce a $0.1428 current-call estimate versus $0.01932 with cache fields supplied. These are synthetic, repository-rate calculations—not a provider invoice or independently verified current pricing. The roughly 7.39× difference demonstrates the arithmetic consequence, not an observed user overcharge.

Repair the boundary without replacing the charge ledger. Carry provider/route identity, normalized cache counters and pricing provenance into settlement. Keep partial usage, unknown usage, estimates and invoice-reported charges distinct. Validate provider-specific token semantics; input totals and cache counters do not have identical meanings across every API. Preserve the original quote basis on replay.

Current owner accounting already preserves late provider charges and has unknown-charge and replay logic. Do not undo this work or describe it as absent. [B16, B17]

### F03 — Compaction trigger and strategy eligibility disagree

**Priority:** P1. **Evidence:** source-confirmed plus P01/P02.

`runChatEngineCompaction()` requests compaction when the reserve-adjusted limit is reached, a token trigger fires, or forced recovery is requested. It then passes the full `maxEstimatedTokens` as the manager's `maxTokens`. Both built-in strategies require `estimatedTokens > maxTokens`. [B08, B09]

Consequently, 95,000 estimated tokens with a 100,000 limit and 8,000 reserve request compaction but select neither strategy. Forced recovery below the full limit has the same mismatch. The manager returns unchanged rather than throwing, so exception-based fallback does not repair this case.

Define one pressure contract: trigger reason, input target, output reserve, irreducible retained floor and preservation requirements. Forced compaction should attempt a valid reduction or report an explicit impossible/no-op reason. After reduction, re-prepare the exact outgoing request. Avoid an unbounded retry loop when mandatory content itself cannot fit.

### F04 — Read-cache identity conflates real filenames

**Priority:** P1. **Evidence:** source-confirmed plus P06/P07; native downstream suppression not reproduced.

`normalizeReadCacheKey()` trims the supplied path and lowercases paths containing `/workspace/` or `/Workspace/`. It therefore gives `/workspace/Repo/A.ts` and `/workspace/Repo/a.ts` one key on a case-sensitive filesystem, and collapses ` A.ts` into `A.ts`. The engine delegates its read-cache key to this helper. [B10, B15]

Reuse established root/path identity rather than invent another normalization authority. Preserve significant filename bytes; infer case behavior from a real filesystem/root policy, not a directory spelling. Do not simply realpath all inputs without handling missing files, symlink policy and permission errors.

The nearby helper also asserts that the model still has previously read content and instructs it to edit. That statement is not justified by a historical read count alone. Native tests should distinguish current revision, delivered range, current context generation and post-compaction re-read. A denied redundant read must not become an unsupported mutation mandate.

### F05 — Exact request bytes do not mean exact context-token qualification

**Priority:** P1 calibration/contract work; bounded null-precedence bug. **Evidence:** source plus P04.

Prepared requests have immutable bytes and a digest—valuable audit properties. Their token estimate is nevertheless approximately UTF-8 payload bytes divided by four, plus per-message overhead. Preserve that distinction in logs, UI and admission semantics. Do not label a heuristic fit as provider-certified fit. [B11, B12]

A separate small contract bug uses `contextLimitTokens ?? inputLimitTokens`. The documented explicit-null value means unknown, but a supplied deprecated alias overrides it. Fix explicit property precedence and test absent, null, numeric, malformed and conflicting fields. This audit did not locate a live caller supplying both fields, so it is not a demonstrated production overflow.

Calibrate the estimator against actual provider usage for the request shapes Babel really emits; establish output reserves and safety margins per supported capability. Unsupported shapes must be explicit, rather than silently analyzed as empty messages. This is not a claim that an unsupported provider shape currently uses this helper.

### F06 — Auxiliary compaction calls need the same lifecycle contract

**Priority:** P1 bounded cancellation repair; broader parity investigation. **Evidence:** source plus P05.

The compaction code retains its own environment-derived route and HTTP implementation. It already checks endpoint/model/credential coherence and emits lifecycle/usage callbacks; claiming that all protection or accounting is absent would be wrong. [B09]

Its parent-signal wiring only adds an abort listener. A parent aborted before listener registration does not abort the new controller. The isolated probe establishes that JavaScript behavior, not that a real Babel task necessarily reaches dispatch after cancellation.

Centralize pre-aborted checks, deadline/retry semantics and prepared-request evidence. Bind auxiliary calls to the original task, route policy and cost owner; disclose when a different summarizer processes repository content. Prove local-only/approved-provider restrictions are respected. No cross-provider disclosure exploit was demonstrated here.

## 3. Coding-loop critique

### Keep the corrected boundaries

Current shared chat preparation labels harness-generated guidance as non-user authorization and uses the resolved task operation. The wire mapper rejects model summaries promoted to system authority. Exact string edits pass through the central governed write path. These changes deserve regression protection, not a fresh rewrite. [B12, B14, B18]

### Challenge policy interactions, not just isolated functions

The engine integrates phase, progress, stall, exploration, completion, recovery, compaction, child and allowance policies. Each may be locally reasonable while their combined behavior makes an agent stall, edit too soon or lose an important failure cause. Source imports establish this integration complexity; they do not prove which policy is hurting success. [B15]

Run ablations against a minimal strong-agent baseline, keeping authority and semantic acceptance unchanged. Useful candidates are advisory mutate-first nudges, read fuses, repeated critics, route waterfalls and child fan-out. Measure both genuine repeated-read prevention and erroneous blocking of necessary exploration. Do not equate fewer reads, fewer turns, a patch's existence or exit code zero with a correct solution.

Prioritize tasks that humans actually ask: explanation without edits; locate a bug; reproduce before fixing; a bounded edit plus tests; cancellation then a different task; provider failure after a partial edit; resume after compaction; and a child finding that must inform the parent answer. Run the same intent through interactive, one-shot and protocol paths.

### Editing and execution details worth checking

Preserve unique-match editing, explicit ambiguity, near-miss diagnostics and central write receipts. Test CRLF, Unicode, simultaneous external edits, symlink/root behavior and unchanged output. Run commands with explicit cwd, timeout, output policy and process-tree cancellation. Do not introduce fuzzy successful edits or universal auto-rollback: either can destroy user changes without a revision-aware transaction policy.

`governedMutations.ts` still writes and restores `process.env.BABEL_PROJECT_ROOT` across an awaited call, despite passing an explicit mutation root. This is a residual concurrency seam for existing #214, not proof of a wrong-root write. It also reads the target before the central write gate and may form near-miss diagnostics. Existing #256 should trace caller read authorization and path confinement before claiming this is safe or exploitable. [B18]

## 4. Context and token-efficiency critique

A good context manager preserves the minimum correct state, not the shortest transcript. The inspected stack already records source and delivered digests, truncation and omission. However, project instructions are packable/truncatable optional content while the safety/provider/verifier core is reserved. Recording omission does not establish that omitted project rules were dispensable. Classify indispensable obligations explicitly within existing context/obligation work. [B13]

Do not build another generic memory layer. Improve retrieval through existing observation, checkpoint, index and thread-history surfaces. Keep authoritative task/approval/revision state deterministic and retrieved file/log content advisory. Every retained or recalled observation should identify source revision and range; unavailable or purged bytes must remain unavailable, not re-created by a summary.

For cache efficiency, instrument the actual assembled prefix and identify changes in instructions, tools, model, route and policy epoch. Stable-prefix assembly is an experiment until actual cache usage demonstrates a benefit. Never preserve a revoked capability merely to keep a cache hit. Prefix length, cache hit fraction and lower request cost are intermediate metrics; completed-task cost is the objective. [B11–B13, M04]

Compare three existing-context strategies behind flags: bounded verbatim-tail pruning with reference handles; existing model summarization; and earlier incremental advisory extraction. Use identical mandatory context and authority rules. Original-history re-pruning is also worth evaluating against recursively summarized context, motivated by recent preprint research; it is not a promised Babel gain. [M03, R01]

## 5. CLI and TUI critique

### CLI

The launcher correctly resolves its own compiled entry. The package still presents several bins and a source-build-oriented failure message. The manifest contains extensive audit, benchmark and reliability tooling; the gap is not a lack of script names. Qualify one first-success path from a clean package artifact and expose the installed identity, source revision, target root, provider/model, effective permissions and diagnostic action clearly. [B19–B21]

Publish an artifact that works without the repository checkout, devDependencies, accidental parent directories or cached credentials. Check package collisions, platform launchers, upgrades, failure diagnostics and uninstall. A successful source-tree run does not establish installability. Keep publish authorization and release qualification separate. Issue #231 explicitly treats npm installer implementation as a separate track.

### TUI

The inspected candidate already has responsive modes, display-width-aware composition, sanitization and changed-row output. Preserve those improvements. Remaining work is product interaction and terminal qualification, not simply drawing more borders. [B22, B23]

Keep the conversation and composer primary. Display target/branch, current action, elapsed time, authoritative reason for waiting, current request context, session/task cost with unknown markers, and the next useful action. Put policy internals and receipt lineage in an inspector. A visible button or tree node must invoke a real supported action or visibly explain why it is unavailable.

Prove resizing during streams, wrapped wide Unicode, paste and IME, copy/selection, transcript scrolling, process interruption, draft preservation and resume. Test real Windows/ConPTY and POSIX PTYs, including an SSH/tmux path. Keep a usable linear/non-TTY fallback. Measure input latency, frame time, emitted bytes, memory and long-transcript behavior before establishing regression ceilings; no performance measurements were taken here.

Consolidate #206 and #267 under one owner. Reconcile ancestry and accepted behavior, qualify the integrated exact head and retire superseded work only with evidence. Do not create a third renderer or merge either PR merely to reduce the open-PR count.

## 6. Competitive interpretation

Codex's current retrieved release and source are the appropriate baseline, not memories of older versions. Its compaction code provides explicit trigger/phase distinctions and consistent initial-context handling; its recent releases emphasize everyday session and terminal workflows. Borrow contracts and acceptance tests, not Rust as an end in itself. [C01–C03]

MiMo is OpenCode-derived. Its inspected source offers concrete reusable ideas: actor-scoped compaction with complete API rounds and explicit omitted-output markers, and persistent system/tool-prefix snapshots keyed by a profile including permissions. Those mechanisms are more actionable than a brand-level benchmark claim. [M03–M05]

The verified Xiaomi launch report compares Claude Code, not Codex; it is vendor-authored evidence and does not establish current controlled superiority. Separate harness/model/compute effects before making a claim. [M02]

An independent model call is not automatically independent evidence custody, and executing generated orchestration code deterministically does not make its plan semantically correct. These are reasons to keep Babel's acceptance boundary while testing simpler worker behavior.

Recommended comparison: (1) same-model, same-budget harness experiment where interfaces permit it; and (2) each product's supported best configuration with price and intervention cost reported. Do not present these as the same experiment.

## 7. Evaluation contract

Extend existing agent-benchmark, canary, live parity, corpus and failure-ledger surfaces. Do not create a second score database just because there is a new audit. The manifest proves these entrypoints exist; this audit did not establish fresh live success rates. [B05, B19]

Primary metric: total cohort spend—including failed tasks, retries, summarizers, child runs and reviewers—divided by semantically accepted tasks. Also report success rate, first-pass acceptance, intervention count, total duration distribution, cost per attempted task and unknown-cost share. Never hide unsuccessful attempts by measuring only successful runs. Zero accepted tasks means the ratio is undefined, not zero cost.

Keep deterministic lifecycle/protocol tests separate from live model trials. Use behavior-based, holdout acceptance checks that the implementation agent cannot modify. Distinguish a verifier's infrastructure failure from a rejected implementation. Version the task, repository, model, harness, prompt, tools, price basis, timeout and cache regime. Repeat tasks and show uncertainty; do not infer quality equivalence from a small no-failure sample.

Suggested pilot, not a benchmark claim: 24 bounded tasks across read-only, single-file, multi-file, recovery/compaction, provider-fault and terminal/entrypoint categories. Start with one public small repository and one Babel fixture, then held-out repositories. Instrument before optimizing, but do not delay obvious contract bug fixes for a large benchmark campaign.

## 8. Beyond the requested surface

Review infrastructure, release packaging and issue hygiene directly affect coding speed and user trust. Measure review wall time, dollars, stale-head invalidations, false blocks and semantic defect catches. Stronger review custody is useful; endless repair of the reviewer itself is not a product success.

Keep existing #259–#265 as staged authority/evidence work after basic daily-driver qualification, not as preconditions to every benign read-only interaction. #266's heterogeneous-producer acceptance direction is sound as a strategy: Babel should be able to judge a candidate produced by another agent without forcing all work through its own worker. This is an incremental boundary, not a new daemon/control-plane rewrite.

Maintain a reproducible public evidence index with exact head and scenario status. A good status line says implemented, tested locally, tested in hosted CI, reviewed, field-qualified, packaged or released separately. This audit's stale issue headers show why those terms cannot be collapsed.

## 9. Deliverables and boundaries

Nine new issue drafts cover six bounded defect/contract areas, native evaluation, an optimization experiment and clean-room packaging. The reconciliation matrix covers the 22 open issues retrieved and includes separate updates for #206/#267. Draft identifiers N01–N09 are local packet identifiers, not GitHub issue numbers or a replacement for P01–P21.

No issue, comment, PR or runtime change was published. The connected GitHub actions exposed reads only. The packet includes a roadmap and an execution handoff, but implementation, current-head verification and permissioned issue publication remain explicit next actions.

See `SOURCES.md`, `ROADMAP.md`, `IMPLEMENTATION_PLAN.md`, `issues/INDEX.md`, `EVALUATION_PROTOCOL.md`, `AGENT_HANDOFF.md`, and `probes/results.json`.
