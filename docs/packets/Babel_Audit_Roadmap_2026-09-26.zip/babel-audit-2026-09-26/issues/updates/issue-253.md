# Proposed update for existing issue #253: In-flight steering / admission

**Not posted.** Re-fetch the issue and current main before applying this update. Audit baseline: `bd155087e41a53599470b86859fe7f45c1036a47`.

## September 26 audit reconciliation
Existing ownership, no duplicate issue needed

## Next action within existing scope
Add pre-aborted summarizer, interrupted draft, stale callback and successor-task cases; link N06.

Source references and execution limitations are in `SOURCES.md` and `snapshot.json`. None of this update closes the issue automatically. Preserve its existing acceptance contract and history. A local source-logic probe is not native integration or independent qualification.
