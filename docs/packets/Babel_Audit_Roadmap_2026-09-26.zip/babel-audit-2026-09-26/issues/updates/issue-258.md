# Proposed update for existing issue #258: Provider quota/capacity semantics

**Not posted.** Re-fetch the issue and current main before applying this update. Audit baseline: `bd155087e41a53599470b86859fe7f45c1036a47`.

## September 26 audit reconciliation
Issue explicitly excludes pricing-registry redesign

## Next action within existing scope
Add ordinary coding/review/summarizer capacity classification parity; N02 owns pricing repair.

Source references and execution limitations are in `SOURCES.md` and `snapshot.json`. None of this update closes the issue automatically. Preserve its existing acceptance contract and history. A local source-logic probe is not native integration or independent qualification.
