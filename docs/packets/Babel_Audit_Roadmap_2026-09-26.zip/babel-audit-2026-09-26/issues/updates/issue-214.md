# Proposed update for existing issue #214: Execution/root/approval isolation

**Not posted.** Re-fetch the issue and current main before applying this update. Audit baseline: `bd155087e41a53599470b86859fe7f45c1036a47`.

## September 26 audit reconciliation
Residual process.env bridge in governedMutations spans await; wrong-root mutation unproven

## Next action within existing scope
Audit ambient readers under concurrent roots and cancel/new-task; remove or isolate bridge without duplicating context authority.

Source references and execution limitations are in `SOURCES.md` and `snapshot.json`. None of this update closes the issue automatically. Preserve its existing acceptance contract and history. A local source-logic probe is not native integration or independent qualification.
