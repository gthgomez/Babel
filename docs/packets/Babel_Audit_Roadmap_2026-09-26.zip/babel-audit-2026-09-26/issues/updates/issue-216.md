# Proposed update for existing issue #216: Fresh-task and instruction-source conformance

**Not posted.** Re-fetch the issue and current main before applying this update. Audit baseline: `bd155087e41a53599470b86859fe7f45c1036a47`.

## September 26 audit reconciliation
Native complete matrix not rerun; read-cache collisions confirmed separately

## Next action within existing scope
Link N04 and run fresh-task, root, instruction, reread and cancellation parity.

Source references and execution limitations are in `SOURCES.md` and `snapshot.json`. None of this update closes the issue automatically. Preserve its existing acceptance contract and history. A local source-logic probe is not native integration or independent qualification.
