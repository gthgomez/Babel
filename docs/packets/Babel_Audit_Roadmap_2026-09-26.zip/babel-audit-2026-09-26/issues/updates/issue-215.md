# Proposed update for existing issue #215: Coordinator lifecycle

**Not posted.** Re-fetch the issue and current main before applying this update. Audit baseline: `bd155087e41a53599470b86859fe7f45c1036a47`.

## September 26 audit reconciliation
Current adoption/retirement not established by this audit

## Next action within existing scope
Resolve scaffold versus production call path; preserve existing issue, no second supervisor.

Source references and execution limitations are in `SOURCES.md` and `snapshot.json`. None of this update closes the issue automatically. Preserve its existing acceptance contract and history. A local source-logic probe is not native integration or independent qualification.
