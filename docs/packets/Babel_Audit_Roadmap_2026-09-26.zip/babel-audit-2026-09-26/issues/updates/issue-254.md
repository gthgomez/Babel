# Proposed update for existing issue #254: Context authority / lifecycle

**Not posted.** Re-fetch the issue and current main before applying this update. Audit baseline: `bd155087e41a53599470b86859fe7f45c1036a47`.

## September 26 audit reconciliation
Existing owner of broader context semantics

## Next action within existing scope
Link N03/N04/N05/N08; preserve required instructions and authority across pruning, prefix epochs and resume.

Source references and execution limitations are in `SOURCES.md` and `snapshot.json`. None of this update closes the issue automatically. Preserve its existing acceptance contract and history. A local source-logic probe is not native integration or independent qualification.
