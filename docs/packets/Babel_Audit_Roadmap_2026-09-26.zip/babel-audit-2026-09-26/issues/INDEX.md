# Issue packet

**Nine new drafts; 22 existing-issue update drafts; one joint PR update. Zero published changes.**

N identifiers are local, not GitHub numbers. Search current open/closed issues again before filing, because GitHub may have changed since retrieval.

## New drafts

- [N01 — ci(windows): reconcile chat-truth skips without weakening the strict coverage gate](new/N01.md) · P0 release qualification
- [N02 — billing: retain cache counters and route-scoped pricing provenance through charge settlement](new/N02.md) · P1
- [N03 — context: unify compaction trigger, target budget and forced-recovery eligibility](new/N03.md) · P1
- [N04 — context: preserve physical path identity and context-generation freshness in read suppression](new/N04.md) · P1
- [N05 — providers: distinguish heuristic context-fit estimates and honor explicit unknown limits](new/N05.md) · P1
- [N06 — providers: give auxiliary compaction calls consistent cancellation, route and accounting contracts](new/N06.md) · P1 cancellation; P2 auxiliary-boundary consolidation
- [N07 — eval: extend existing native harness trials with full-cohort cost per semantically accepted task](new/N07.md) · P1 qualification
- [N08 — perf(context): ablate stable prefixes and reference-backed pruning without weakening authority](new/N08.md) · P2 experiment, off by default
- [N09 — release: qualify a clean-room CLI package and one first-success onboarding path](new/N09.md) · P2 product qualification

## Existing work

See `existing-issue-reconciliation.csv` and `updates/`. Keep issue #217 as the roadmap owner. #258 does not own pricing redesign; #231 does not own installer runtime implementation. The related issues are links, not a request to merge distinct scopes.

## Publishing

`new-issues.json` contains titles, body file paths, existing-related issue numbers, evidence and baseline. Use an authorized issue-writing tool in a later execution environment. Confirm duplicates first, create only genuinely new issues, then patch local IDs to returned GitHub numbers. Do not claim publication until the tool returns each created issue. Never copy private logs, credentials or user repository content into public issue bodies.
